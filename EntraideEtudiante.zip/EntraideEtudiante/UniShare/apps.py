from django.apps import AppConfig


class UnishareConfig(AppConfig):
    name = "UniShare"
